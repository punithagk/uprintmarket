UC Option Image for Drupal 7 and UC 3

This is a complete rewrite of the UC Option Image module for Drupal 7.

Some functionality has changed with respect to the D6 version.  Specifically:

* You may set an image / image style combination at any point, and it will acts as a default value for more specific settings.  You may configure at any of these levels:
  - Attribute
  - Option
  - Specific product

* You may define how images should display using the standard image styles.

