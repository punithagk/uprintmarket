(function ($) {  // Put definition of $ into local scope so jQuery code
                 // doesn't conflict with other JavaScript libraries
  Drupal.behaviors.uc_fedex = function() {
  };

}) (jQuery);  // End local scope for $
